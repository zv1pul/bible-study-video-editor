cimport libav as lib

from av.filter.filter cimport Filter
from av.filter.graph cimport Graph


cdef class FilterContext:
    cdef lib.AVFilterContext *ptr
    cdef readonly Graph graph
    cdef readonly Filter filter
    cdef bint inited
    cdef unsigned char _kind


cdef FilterContext wrap_filter_context(Graph graph, Filter filter, lib.AVFilterContext *ptr)
