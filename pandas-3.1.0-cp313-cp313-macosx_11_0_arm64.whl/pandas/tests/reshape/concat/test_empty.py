import struct

import numpy as np
import pytest

import pandas as pd
import pandas._testing as tm


class TestEmptyConcat:
    def test_handle_empty_objects(self, sort, using_infer_string):
        df = pd.DataFrame(
            np.random.default_rng(2).standard_normal((10, 4)), columns=list("abcd")
        )

        dfcopy = df[:5].copy()
        dfcopy["foo"] = "bar"
        empty = df[5:5]

        frames = [dfcopy, empty, empty, df[5:]]
        concatted = pd.concat(frames, axis=0, sort=sort)

        expected = df.reindex(columns=["a", "b", "c", "d", "foo"])
        expected["foo"] = expected["foo"].astype(
            object if not using_infer_string else "str"
        )
        expected.loc[0:4, "foo"] = "bar"

        tm.assert_frame_equal(concatted, expected)

        # empty as first element with time series
        # GH3259
        df = pd.DataFrame(
            {"A": range(1000)}, index=pd.date_range("20130101", periods=1000, freq="s")
        )
        empty = pd.DataFrame()
        result = pd.concat([df, empty], axis=1)
        tm.assert_frame_equal(result, df)
        result = pd.concat([empty, df], axis=1)
        tm.assert_frame_equal(result, df)

        result = pd.concat([df, empty])
        tm.assert_frame_equal(result, df)
        result = pd.concat([empty, df])
        tm.assert_frame_equal(result, df)

    def test_concat_empty_series(self):
        # GH 11082
        s1 = pd.Series([1, 2, 3], name="x")
        s2 = pd.Series(name="y", dtype="float64")
        res = pd.concat([s1, s2], axis=1)
        exp = pd.DataFrame(
            {"x": [1, 2, 3], "y": [np.nan, np.nan, np.nan]},
            index=pd.RangeIndex(3),
        )
        tm.assert_frame_equal(res, exp)

        s1 = pd.Series([1, 2, 3], name="x")
        s2 = pd.Series(name="y", dtype="float64")
        res = pd.concat([s1, s2], axis=0)
        # name will be reset
        exp = pd.Series([1, 2, 3], dtype="float64")
        tm.assert_series_equal(res, exp)

        # empty Series with no name
        s1 = pd.Series([1, 2, 3], name="x")
        s2 = pd.Series(name=None, dtype="float64")
        res = pd.concat([s1, s2], axis=1)
        exp = pd.DataFrame(
            {"x": [1, 2, 3], 0: [np.nan, np.nan, np.nan]},
            columns=["x", 0],
            index=pd.RangeIndex(3),
        )
        tm.assert_frame_equal(res, exp)

    @pytest.mark.parametrize("tz", [None, "UTC"])
    @pytest.mark.parametrize("values", [[], [1, 2, 3]])
    def test_concat_empty_series_timelike(self, tz, values):
        # GH 18447

        first = pd.Series([], dtype="M8[ns]").dt.tz_localize(tz)
        dtype = None if values else np.float64
        second = pd.Series(values, dtype=dtype)

        expected = pd.DataFrame(
            {
                0: pd.Series([pd.NaT] * len(values), dtype="M8[ns]").dt.tz_localize(tz),
                1: values,
            }
        )
        result = pd.concat([first, second], axis=1)
        tm.assert_frame_equal(result, expected)

    @pytest.mark.parametrize(
        "left,right,expected",
        [
            # booleans
            (np.bool_, np.int32, np.object_),  # changed from int32 in 2.0 GH#39817
            (np.bool_, np.float32, np.object_),
            # datetime-like
            ("m8[ns]", np.bool_, np.object_),
            ("m8[ns]", np.int64, np.object_),
            ("M8[ns]", np.bool_, np.object_),
            ("M8[ns]", np.int64, np.object_),
            # categorical
            ("category", "category", "category"),
            ("category", "object", "object"),
        ],
    )
    def test_concat_empty_series_dtypes(self, left, right, expected):
        # GH#39817, GH#45101
        result = pd.concat([pd.Series(dtype=left), pd.Series(dtype=right)])
        assert result.dtype == expected

    @pytest.mark.parametrize(
        "dtype", ["float64", "int8", "uint8", "bool", "m8[ns]", "M8[ns]"]
    )
    def test_concat_empty_series_dtypes_match_roundtrips(self, dtype):
        dtype = np.dtype(dtype)

        result = pd.concat([pd.Series(dtype=dtype)])
        assert result.dtype == dtype

        result = pd.concat([pd.Series(dtype=dtype), pd.Series(dtype=dtype)])
        assert result.dtype == dtype

    @pytest.mark.parametrize("dtype", ["float64", "int8", "uint8", "m8[ns]", "M8[ns]"])
    @pytest.mark.parametrize(
        "dtype2",
        ["float64", "int8", "uint8", "m8[ns]", "M8[ns]"],
    )
    def test_concat_empty_series_dtypes_roundtrips(self, dtype, dtype2):
        # round-tripping with self & like self
        if dtype == dtype2:
            pytest.skip("same dtype is not applicable for test")

        def int_result_type(dtype, dtype2):
            typs = {dtype.kind, dtype2.kind}
            if not len(typs - {"i", "u", "b"}) and (
                dtype.kind == "i" or dtype2.kind == "i"
            ):
                return "i"
            elif not len(typs - {"u", "b"}) and (
                dtype.kind == "u" or dtype2.kind == "u"
            ):
                return "u"
            return None

        def float_result_type(dtype, dtype2):
            typs = {dtype.kind, dtype2.kind}
            if not len(typs - {"f", "i", "u"}) and (
                dtype.kind == "f" or dtype2.kind == "f"
            ):
                return "f"
            return None

        def get_result_type(dtype, dtype2):
            result = float_result_type(dtype, dtype2)
            if result is not None:
                return result
            result = int_result_type(dtype, dtype2)
            if result is not None:
                return result
            return "O"

        dtype = np.dtype(dtype)
        dtype2 = np.dtype(dtype2)
        expected = get_result_type(dtype, dtype2)
        result = pd.concat([pd.Series(dtype=dtype), pd.Series(dtype=dtype2)]).dtype
        assert result.kind == expected

    def test_concat_empty_series_dtypes_triple(self):
        assert (
            pd.concat(
                [
                    pd.Series(dtype="M8[ns]"),
                    pd.Series(dtype=np.bool_),
                    pd.Series(dtype=np.int64),
                ]
            ).dtype
            == np.object_
        )

    def test_concat_empty_series_dtype_category_with_array(self):
        # GH#18515
        assert (
            pd.concat(
                [pd.Series(np.array([]), dtype="category"), pd.Series(dtype="float64")]
            ).dtype
            == "float64"
        )

    def test_concat_empty_series_dtypes_sparse(self):
        result = pd.concat(
            [
                pd.Series(dtype="float64").astype("Sparse"),
                pd.Series(dtype="float64").astype("Sparse"),
            ]
        )
        assert result.dtype == "Sparse[float64]"

        result = pd.concat(
            [pd.Series(dtype="float64").astype("Sparse"), pd.Series(dtype="float64")]
        )
        expected = pd.SparseDtype(np.float64)
        assert result.dtype == expected

        result = pd.concat(
            [pd.Series(dtype="float64").astype("Sparse"), pd.Series(dtype="object")]
        )
        expected = pd.SparseDtype("object")
        assert result.dtype == expected

    def test_concat_empty_df_object_dtype(self):
        # GH 9149
        df_1 = pd.DataFrame(
            {"Row": [0, 1, 1], "EmptyCol": np.nan, "NumberCol": [1, 2, 3]}
        )
        df_2 = pd.DataFrame(columns=df_1.columns)
        result = pd.concat([df_1, df_2], axis=0)
        expected = df_1.astype(object)
        tm.assert_frame_equal(result, expected)

    def test_concat_empty_dataframe_dtypes(self):
        df = pd.DataFrame(columns=list("abc"))
        df["a"] = df["a"].astype(np.bool_)
        df["b"] = df["b"].astype(np.int32)
        df["c"] = df["c"].astype(np.float64)

        result = pd.concat([df, df])
        assert result["a"].dtype == np.bool_
        assert result["b"].dtype == np.int32
        assert result["c"].dtype == np.float64

        result = pd.concat([df, df.astype(np.float64)])
        assert result["a"].dtype == np.object_
        assert result["b"].dtype == np.float64
        assert result["c"].dtype == np.float64

    def test_concat_inner_join_empty(self):
        # GH 15328
        df_empty = pd.DataFrame()
        df_a = pd.DataFrame({"a": [1, 2]}, index=[0, 1], dtype="int64")
        df_expected = pd.DataFrame({"a": []}, index=pd.RangeIndex(0), dtype="int64")

        result = pd.concat([df_a, df_empty], axis=1, join="inner")
        tm.assert_frame_equal(result, df_expected)

        result = pd.concat([df_a, df_empty], axis=1, join="outer")
        tm.assert_frame_equal(result, df_a)

    def test_empty_dtype_coerce(self):
        # xref to #12411
        # xref to #12045
        # xref to #11594
        # see below

        # 10571
        df1 = pd.DataFrame(data=[[1, None], [2, None]], columns=["a", "b"])
        df2 = pd.DataFrame(data=[[3, None], [4, None]], columns=["a", "b"])
        result = pd.concat([df1, df2])
        expected = df1.dtypes
        tm.assert_series_equal(result.dtypes, expected)

    def test_concat_empty_dataframe(self):
        # 39037
        df1 = pd.DataFrame(columns=["a", "b"])
        df2 = pd.DataFrame(columns=["b", "c"])
        result = pd.concat([df1, df2, df1])
        expected = pd.DataFrame(columns=["a", "b", "c"])
        tm.assert_frame_equal(result, expected)

        df3 = pd.DataFrame(columns=["a", "b"])
        df4 = pd.DataFrame(columns=["b"])
        result = pd.concat([df3, df4])
        expected = pd.DataFrame(columns=["a", "b"])
        tm.assert_frame_equal(result, expected)

    def test_concat_empty_dataframe_different_dtypes(self, using_infer_string):
        # 39037
        df1 = pd.DataFrame({"a": [1, 2, 3], "b": ["a", "b", "c"]})
        df2 = pd.DataFrame({"a": [1, 2, 3]})

        result = pd.concat([df1[:0], df2[:0]])
        assert result["a"].dtype == np.int64
        assert result["b"].dtype == np.object_ if not using_infer_string else "str"

    def test_concat_to_empty_ea(self):
        """48510 `concat` to an empty EA should maintain type EA dtype."""
        df_empty = pd.DataFrame({"a": pd.array([], dtype=pd.Int64Dtype())})
        df_new = pd.DataFrame({"a": pd.array([1, 2, 3], dtype=pd.Int64Dtype())})
        expected = df_new.copy()
        result = pd.concat([df_empty, df_new])
        tm.assert_frame_equal(result, expected)


def test_concat_preserves_nan_payload():
    # GH#51675 concat must not replace user-supplied NaN bit patterns
    payload_nan = struct.unpack(">d", bytes.fromhex("fffffffffffffffe"))[0]
    values = np.array([payload_nan, np.nan], dtype=np.float64)

    df = pd.DataFrame(values)
    empty = pd.DataFrame([], columns=[0], dtype=np.float64)

    for frames in ([df, empty], [empty, df], [df, df.iloc[:0]]):
        result = pd.concat(frames)[0].to_numpy()
        result_bytes = result[: len(values)].tobytes()
        assert result_bytes == values.tobytes()
