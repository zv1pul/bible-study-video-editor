import pytest

from pandas.errors import Pandas4Warning

import pandas as pd
import pandas._testing as tm
from pandas.api.types import is_bool_dtype


@pytest.mark.parametrize(
    "data, index, drop_labels, axis, expected_data, expected_index",
    [
        # Unique Index
        ([1, 2], ["one", "two"], ["two"], 0, [1], ["one"]),
        ([1, 2], ["one", "two"], ["two"], "rows", [1], ["one"]),
        ([1, 1, 2], ["one", "two", "one"], ["two"], 0, [1, 2], ["one", "one"]),
        # GH 5248 Non-Unique Index
        ([1, 1, 2], ["one", "two", "one"], "two", 0, [1, 2], ["one", "one"]),
        ([1, 1, 2], ["one", "two", "one"], ["one"], 0, [1], ["two"]),
        ([1, 1, 2], ["one", "two", "one"], "one", 0, [1], ["two"]),
    ],
)
def test_drop_unique_and_non_unique_index(
    data, index, axis, drop_labels, expected_data, expected_index
):
    ser = pd.Series(data=data, index=index)
    result = ser.drop(drop_labels, axis=axis)
    expected = pd.Series(data=expected_data, index=expected_index)
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize(
    "drop_labels, axis, error_type, error_desc",
    [
        # single string/tuple-like
        ("bc", 0, KeyError, "not found in axis"),
        # bad axis
        (("a",), 0, KeyError, "not found in axis"),
        ("one", "columns", ValueError, "No axis named columns"),
    ],
)
def test_drop_exception_raised(drop_labels, axis, error_type, error_desc):
    ser = pd.Series(range(3), index=list("abc"))
    with pytest.raises(error_type, match=error_desc):
        ser.drop(drop_labels, axis=axis)


def test_drop_with_ignore_errors():
    # errors='ignore'
    ser = pd.Series(range(3), index=list("abc"))
    result = ser.drop("bc", errors="ignore")
    tm.assert_series_equal(result, ser)
    result = ser.drop(["a", "d"], errors="ignore")
    expected = ser.iloc[1:]
    tm.assert_series_equal(result, expected)

    # GH 8522
    ser = pd.Series([2, 3], index=[True, False])
    assert is_bool_dtype(ser.index)
    assert ser.index.dtype == bool
    result = ser.drop(True)
    expected = pd.Series([3], index=[False])
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("index", [[1, 2, 3], [1, 1, 3]])
@pytest.mark.parametrize("drop_labels", [[], [1], [3]])
def test_drop_empty_list(index, drop_labels):
    # GH 21494
    expected_index = [i for i in index if i not in drop_labels]
    series = pd.Series(index=index, dtype=object).drop(drop_labels)
    expected = pd.Series(index=expected_index, dtype=object)
    tm.assert_series_equal(series, expected)


@pytest.mark.parametrize(
    "data, index, drop_labels",
    [
        (None, [1, 2, 3], [1, 4]),
        (None, [1, 2, 2], [1, 4]),
        ([2, 3], [0, 1], [False, True]),
    ],
)
def test_drop_non_empty_list(data, index, drop_labels):
    # GH 21494 and GH 16877
    dtype = object if data is None else None
    ser = pd.Series(data=data, index=index, dtype=dtype)
    with pytest.raises(KeyError, match="not found in axis"):
        ser.drop(drop_labels)


def test_drop_index_ea_dtype(any_numeric_ea_dtype):
    # GH#45860
    df = pd.Series(100, index=pd.Index([1, 2, 2], dtype=any_numeric_ea_dtype))
    idx = pd.Index([df.index[1]])
    result = df.drop(idx)
    expected = pd.Series(100, index=pd.Index([1], dtype=any_numeric_ea_dtype))
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("tz", [None, "Asia/Tokyo", "US/Pacific"])
def test_drop_preserves_datetimeindex_freq_and_tz(tz, unit):
    dti = pd.date_range(
        "2000-01-01 09:00", periods=10, freq="h", name="idx", tz=tz, unit=unit
    )
    ts = pd.Series(
        1,
        index=dti,
    )
    # preserve freq
    result = ts.drop(ts.index[:5]).index
    expected = dti[5:]
    tm.assert_index_equal(result, expected)
    assert result.name == expected.name
    assert result.freq == expected.freq
    assert result.tz == expected.tz

    # reset freq to None
    result = ts.drop(ts.index[[1, 3, 5, 7, 9]]).index
    expected = dti[::2]._with_freq(None)
    tm.assert_index_equal(result, expected)
    assert result.name == expected.name
    assert result.freq == expected.freq
    assert result.tz == expected.tz


def test_drop_inplace_depr():
    msg = "The inplace keyword in Series.drop is deprecated"

    ser = pd.Series([1, 2, 3], index=["a", "b", "c"])
    ser_orig = ser.copy()
    expected = pd.Series([2, 3], index=["b", "c"])

    # does not use keyword, no warning
    with tm.assert_produces_warning(False):
        result = ser.drop("a")
    tm.assert_series_equal(result, expected)
    tm.assert_series_equal(ser, ser_orig)

    # uses keyword, set to false, warning
    with tm.assert_produces_warning(Pandas4Warning, match=msg):
        result = ser.drop("a", inplace=False)
    tm.assert_series_equal(result, expected)
    tm.assert_series_equal(ser, ser_orig)

    # uses keyword, set to true, warning
    with tm.assert_produces_warning(Pandas4Warning, match=msg):
        ser.drop("a", inplace=True)
    tm.assert_series_equal(ser, expected)
