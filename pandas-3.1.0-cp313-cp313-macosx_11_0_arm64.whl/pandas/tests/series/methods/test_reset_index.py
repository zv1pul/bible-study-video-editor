from datetime import datetime

import numpy as np
import pytest

from pandas.errors import Pandas4Warning

import pandas as pd
import pandas._testing as tm


class TestResetIndex:
    def test_reset_index_dti_round_trip(self):
        dti = pd.date_range(
            start="1/1/2001", end="6/1/2001", freq="D", unit="ns"
        )._with_freq(None)
        d1 = pd.DataFrame({"v": np.random.default_rng(2).random(len(dti))}, index=dti)
        d2 = d1.reset_index()
        assert d2.dtypes.iloc[0] == np.dtype("M8[ns]")
        d3 = d2.set_index("index")
        tm.assert_frame_equal(d1, d3, check_names=False)

        # GH#2329
        stamp = datetime(2012, 11, 22)
        df = pd.DataFrame([[stamp, 12.1]], columns=["Date", "Value"])
        df = df.set_index("Date")

        assert df.index[0] == stamp
        assert df.reset_index()["Date"].iloc[0] == stamp

    @pytest.mark.filterwarnings("ignore:The inplace keyword in Series.reset_index")
    def test_reset_index(self):
        df = pd.DataFrame(
            1.1 * np.arange(120).reshape((30, 4)),
            columns=pd.Index(list("ABCD"), dtype=object),
            index=pd.Index([f"i-{i}" for i in range(30)], dtype=object),
        )[:5]
        ser = df.stack()
        ser.index.names = ["hash", "category"]

        ser.name = "value"
        df = ser.reset_index()
        assert "value" in df

        df = ser.reset_index(name="value2")
        assert "value2" in df

        # check inplace
        s = ser.reset_index(drop=True)
        s2 = ser
        return_value = s2.reset_index(drop=True, inplace=True)
        assert return_value is None
        tm.assert_series_equal(s, s2)

        # level
        index = pd.MultiIndex(
            levels=[["bar"], ["one", "two", "three"], [0, 1]],
            codes=[[0, 0, 0, 0, 0, 0], [0, 1, 2, 0, 1, 2], [0, 1, 0, 1, 0, 1]],
        )
        s = pd.Series(np.random.default_rng(2).standard_normal(6), index=index)
        rs = s.reset_index(level=1)
        assert len(rs.columns) == 2

        rs = s.reset_index(level=[0, 2], drop=True)
        tm.assert_index_equal(rs.index, pd.Index(index.get_level_values(1)))
        assert isinstance(rs, pd.Series)

    def test_reset_index_name(self):
        s = pd.Series([1, 2, 3], index=pd.Index(range(3), name="x"))
        assert s.reset_index().index.name is None
        assert s.reset_index(drop=True).index.name is None

    def test_reset_index_level(self):
        df = pd.DataFrame([[1, 2, 3], [4, 5, 6]], columns=["A", "B", "C"])

        for levels in ["A", "B"], [0, 1]:
            # With MultiIndex
            s = df.set_index(["A", "B"])["C"]

            result = s.reset_index(level=levels[0])
            tm.assert_frame_equal(result, df.set_index("B"))

            result = s.reset_index(level=levels[:1])
            tm.assert_frame_equal(result, df.set_index("B"))

            result = s.reset_index(level=levels)
            tm.assert_frame_equal(result, df)

            result = df.set_index(["A", "B"]).reset_index(level=levels, drop=True)
            tm.assert_frame_equal(result, df[["C"]])

            with pytest.raises(KeyError, match="Level E "):
                s.reset_index(level=["A", "E"])

            # With single-level Index
            s = df.set_index("A")["B"]

            result = s.reset_index(level=levels[0])
            tm.assert_frame_equal(result, df[["A", "B"]])

            result = s.reset_index(level=levels[:1])
            tm.assert_frame_equal(result, df[["A", "B"]])

            result = s.reset_index(level=levels[0], drop=True)
            tm.assert_series_equal(result, df["B"])

            with pytest.raises(IndexError, match="Too many levels"):
                s.reset_index(level=[0, 1, 2])

        # Check that .reset_index([],drop=True) doesn't fail
        result = pd.Series(range(4)).reset_index([], drop=True)
        expected = pd.Series(range(4))
        tm.assert_series_equal(result, expected)

    def test_reset_index_range(self):
        # GH 12071
        s = pd.Series(range(2), name="A", dtype="int64")
        series_result = s.reset_index()
        assert isinstance(series_result.index, pd.RangeIndex)
        series_expected = pd.DataFrame(
            [[0, 0], [1, 1]], columns=["index", "A"], index=pd.RangeIndex(stop=2)
        )
        tm.assert_frame_equal(series_result, series_expected)

    def test_reset_index_drop_errors(self):
        #  GH 20925

        # KeyError raised for series index when passed level name is missing
        s = pd.Series(range(4))
        with pytest.raises(KeyError, match="does not match index name"):
            s.reset_index("wrong", drop=True)
        with pytest.raises(KeyError, match="does not match index name"):
            s.reset_index("wrong")

        # KeyError raised for series when level to be dropped is missing
        s = pd.Series(range(4), index=pd.MultiIndex.from_product([[1, 2]] * 2))
        with pytest.raises(KeyError, match="not found"):
            s.reset_index("wrong", drop=True)

    def test_reset_index_with_drop(self):
        arrays = [
            ["bar", "bar", "baz", "baz", "qux", "qux", "foo", "foo"],
            ["one", "two", "one", "two", "one", "two", "one", "two"],
        ]
        tuples = zip(*arrays, strict=True)
        index = pd.MultiIndex.from_tuples(tuples)
        data = np.random.default_rng(2).standard_normal(8)
        ser = pd.Series(data, index=index)
        ser.iloc[3] = np.nan

        deleveled = ser.reset_index()
        assert isinstance(deleveled, pd.DataFrame)
        assert len(deleveled.columns) == len(ser.index.levels) + 1
        assert deleveled.index.name == ser.index.name

        deleveled = ser.reset_index(drop=True)
        assert isinstance(deleveled, pd.Series)
        assert deleveled.index.name == ser.index.name

    def test_reset_index_drop_ignore_name(self):
        # GH#44575
        ser = pd.Series(range(2), name="old")
        result = ser.reset_index(name="new", drop=True)
        expected = pd.Series(range(2), name="old")
        tm.assert_series_equal(result, expected)

    @pytest.mark.filterwarnings(
        "ignore:The 'future.infer_string' option:pandas.errors.Pandas4Warning"
    )
    def test_reset_index_drop_infer_string(self):
        # GH#56160
        pytest.importorskip("pyarrow")
        ser = pd.Series(["a", "b", "c"], dtype=object)
        with pd.option_context("future.infer_string", True):
            result = ser.reset_index(drop=True)
        tm.assert_series_equal(result, ser)


@pytest.mark.parametrize(
    "array, dtype",
    [
        (["a", "b"], object),
        (
            pd.period_range("12-1-2000", periods=2, freq="Q-DEC"),
            pd.PeriodDtype(freq="Q-DEC"),
        ),
    ],
)
def test_reset_index_dtypes_on_empty_series_with_multiindex(
    array, dtype, using_infer_string
):
    # GH 19602 - Preserve dtype on empty Series with MultiIndex
    idx = pd.MultiIndex.from_product([[0, 1], [0.5, 1.0], array])
    result = pd.Series(dtype=object, index=idx)[:0].reset_index().dtypes
    exp = "str" if using_infer_string else object
    expected = pd.Series(
        {
            "level_0": np.int64,
            "level_1": np.float64,
            "level_2": exp if dtype == object else dtype,
            0: object,
        }
    )
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize(
    "names, expected_names",
    [
        (["A", "A"], ["A", "A"]),
        (["level_1", None], ["level_1", "level_1"]),
    ],
)
@pytest.mark.parametrize("allow_duplicates", [False, True])
def test_column_name_duplicates(names, expected_names, allow_duplicates):
    # GH#44755 reset_index with duplicate column labels
    s = pd.Series([1], index=pd.MultiIndex.from_arrays([[1], [1]], names=names))
    if allow_duplicates:
        result = s.reset_index(allow_duplicates=True)
        expected = pd.DataFrame([[1, 1, 1]], columns=[*expected_names, 0])
        tm.assert_frame_equal(result, expected)
    else:
        with pytest.raises(ValueError, match="cannot insert"):
            s.reset_index()


def test_reset_index_inplace_depr():
    msg = "The inplace keyword in Series.reset_index is deprecated"

    ser = pd.Series([1, 2, 3], index=["a", "b", "c"])
    ser_orig = ser.copy()
    expected = pd.Series([1, 2, 3])

    # does not use keyword, no warning
    with tm.assert_produces_warning(False):
        result = ser.reset_index(drop=True)
    tm.assert_series_equal(result, expected)
    tm.assert_series_equal(ser, ser_orig)

    # uses keyword, set to false, warning
    with tm.assert_produces_warning(Pandas4Warning, match=msg):
        result = ser.reset_index(drop=True, inplace=False)
    tm.assert_series_equal(result, expected)
    tm.assert_series_equal(ser, ser_orig)

    # uses keyword, set to true, warning
    with tm.assert_produces_warning(Pandas4Warning, match=msg):
        ser.reset_index(drop=True, inplace=True)
    tm.assert_series_equal(ser, expected)
