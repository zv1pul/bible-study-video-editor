from collections import deque
from datetime import (
    UTC,
    date,
    timedelta,
)
from decimal import Decimal
from enum import (
    Enum,
    auto,
)
import operator

import numpy as np
import pytest

from pandas._libs import lib
from pandas.errors import Pandas4Warning

import pandas as pd
import pandas._testing as tm
from pandas.core import ops
from pandas.core.computation import expressions as expr


@pytest.fixture(autouse=True, params=[0, 1000000], ids=["numexpr", "python"])
def switch_numexpr_min_elements(request, monkeypatch):
    with monkeypatch.context() as m:
        m.setattr(expr, "_MIN_ELEMENTS", request.param)
        yield


def _permute(obj):
    return obj.take(np.random.default_rng(2).permutation(len(obj)))


class TestSeriesFlexArithmetic:
    @pytest.mark.parametrize(
        "ts",
        [
            (lambda x: x, lambda x: x * 2, False),
            (lambda x: x, lambda x: x[::2], False),
            (lambda x: x, lambda x: 5, True),
            (
                lambda x: pd.Series(range(10), dtype=np.float64),
                lambda x: pd.Series(range(10), dtype=np.float64),
                True,
            ),
        ],
    )
    @pytest.mark.parametrize(
        "opname", ["add", "sub", "mul", "floordiv", "truediv", "pow"]
    )
    def test_flex_method_equivalence(self, opname, ts):
        # check that Series.{opname} behaves like Series.__{opname}__,
        tser = pd.Series(
            np.arange(20, dtype=np.float64),
            index=pd.date_range("2020-01-01", periods=20),
            name="ts",
        )

        series = ts[0](tser)
        other = ts[1](tser)
        check_reverse = ts[2]

        op = getattr(pd.Series, opname)
        alt = getattr(operator, opname)

        result = op(series, other)
        expected = alt(series, other)
        tm.assert_almost_equal(result, expected)
        if check_reverse:
            rop = getattr(pd.Series, "r" + opname)
            result = rop(series, other)
            expected = alt(other, series)
            tm.assert_almost_equal(result, expected)

    def test_flex_method_subclass_metadata_preservation(self, all_arithmetic_operators):
        # GH 13208
        class MySeries(pd.Series):
            _metadata = ["x"]

            @property
            def _constructor(self):
                return MySeries

        opname = all_arithmetic_operators
        op = getattr(pd.Series, opname)
        m = MySeries([1, 2, 3], name="test")
        m.x = 42
        result = op(m, 1)
        assert result.x == 42

    def test_flex_add_scalar_fill_value(self):
        # GH12723
        ser = pd.Series([0, 1, np.nan, 3, 4, 5])

        exp = ser.fillna(0).add(2)
        res = ser.add(2, fill_value=0)
        tm.assert_series_equal(res, exp)

    pairings = [(pd.Series.div, operator.truediv, 1), (pd.Series.rdiv, ops.rtruediv, 1)]
    for op in ["add", "sub", "mul", "pow", "truediv", "floordiv"]:
        fv = 0
        lop = getattr(pd.Series, op)
        lequiv = getattr(operator, op)
        rop = getattr(pd.Series, "r" + op)
        # bind op at definition time...
        requiv = lambda x, y, op=op: getattr(operator, op)(y, x)
        pairings.append((lop, lequiv, fv))
        pairings.append((rop, requiv, fv))

    @pytest.mark.parametrize("op, equiv_op, fv", pairings)
    def test_operators_combine(self, op, equiv_op, fv):
        def _check_fill(meth, op, a, b, fill_value=0):
            exp_index = a.index.union(b.index)
            a = a.reindex(exp_index)
            b = b.reindex(exp_index)

            amask = pd.isna(a)
            bmask = pd.isna(b)

            # Use to_numpy to work with NumPy scalars so that op has NumPy semantics
            # like the flex methods.
            avals = a.to_numpy()
            bvals = b.to_numpy()

            exp_values = []
            for i in range(len(exp_index)):
                with np.errstate(all="ignore"):
                    if amask[i]:
                        if bmask[i]:
                            exp_values.append(np.nan)
                            continue
                        exp_values.append(op(fill_value, bvals[i]))
                    elif bmask[i]:
                        if amask[i]:
                            exp_values.append(np.nan)
                            continue
                        exp_values.append(op(avals[i], fill_value))
                    else:
                        exp_values.append(op(avals[i], bvals[i]))

            result = meth(a, b, fill_value=fill_value)
            expected = pd.Series(exp_values, exp_index)
            tm.assert_series_equal(result, expected)

        a = pd.Series([np.nan, 1.0, 2.0, 3.0, np.nan], index=np.arange(5))
        b = pd.Series([np.nan, 1, np.nan, 3, np.nan, 4.0], index=np.arange(6))

        result = op(a, b)
        exp = equiv_op(a, b)
        tm.assert_series_equal(result, exp)
        _check_fill(op, equiv_op, a, b, fill_value=fv)
        # should accept axis=0 or axis='rows'
        op(a, b, axis=0)

    @pytest.mark.parametrize("kind", ["datetime", "timedelta"])
    def test_rhs_extension_array_sub_with_fill_value(self, kind):
        # GH:62467
        if kind == "datetime":
            left = pd.Series(
                [pd.Timestamp("2025-08-20"), pd.Timestamp("2025-08-21")],
                dtype=np.dtype("datetime64[ns]"),
            )
        else:
            left = pd.Series(
                [pd.Timedelta(days=1), pd.Timedelta(days=2)],
                dtype=np.dtype("timedelta64[ns]"),
            )

        right = (
            left._values
        )  # DatetimeArray or TimedeltaArray which is an ExtensionArray

        result = left.sub(right, fill_value=left.iloc[0])
        expected = pd.Series(np.zeros(len(left), dtype=np.dtype("timedelta64[ns]")))
        tm.assert_series_equal(result, expected)

    def test_flex_disallows_dataframe(self):
        # GH#46179
        df = pd.DataFrame(
            {2010: [1], 2020: [3]},
            index=pd.MultiIndex.from_product([["a"], ["b"]], names=["scen", "mod"]),
        )

        ser = pd.Series(
            [10.0, 20.0, 30.0],
            index=pd.MultiIndex.from_product(
                [["a"], ["b"], [0, 1, 2]], names=["scen", "mod", "id"]
            ),
        )

        msg = "Series.add does not support a DataFrame `other`"
        with pytest.raises(TypeError, match=msg):
            ser.add(df, axis=0)


class TestSeriesArithmetic:
    # Some of these may end up in tests/arithmetic, but are not yet sorted

    def test_add_series_with_period_index(self):
        rng = pd.period_range("1/1/2000", "1/1/2010", freq="Y")
        ts = pd.Series(np.random.default_rng(2).standard_normal(len(rng)), index=rng)

        result = ts + ts[::2]
        expected = ts + ts
        expected.iloc[1::2] = np.nan
        tm.assert_series_equal(result, expected)

        result = ts + _permute(ts[::2])
        tm.assert_series_equal(result, expected)

    @pytest.mark.parametrize(
        "target_add,input_value,expected_value",
        [
            ("!", ["hello", "world"], ["hello!", "world!"]),
            ("m", ["hello", "world"], ["hellom", "worldm"]),
        ],
    )
    def test_string_addition(self, target_add, input_value, expected_value):
        # GH28658 - ensure adding 'm' does not raise an error
        a = pd.Series(input_value)

        result = a + target_add
        expected = pd.Series(expected_value)
        tm.assert_series_equal(result, expected)

    def test_divmod(self):
        # GH#25557
        a = pd.Series([1, 1, 1, np.nan], index=["a", "b", "c", "d"])
        b = pd.Series([2, np.nan, 1, np.nan], index=["a", "b", "d", "e"])

        result = a.divmod(b)
        expected = divmod(a, b)
        tm.assert_series_equal(result[0], expected[0])
        tm.assert_series_equal(result[1], expected[1])

        result = a.rdivmod(b)
        expected = divmod(b, a)
        tm.assert_series_equal(result[0], expected[0])
        tm.assert_series_equal(result[1], expected[1])

    @pytest.mark.parametrize("index", [None, range(9)])
    def test_series_integer_mod(self, index):
        # GH#24396
        s1 = pd.Series(range(1, 10))
        s2 = pd.Series("foo", index=index)

        msg = "|".join(
            [
                "not all arguments converted during string formatting",
                "'mod' not supported",
            ]
        )

        with pytest.raises(TypeError, match=msg):
            s2 % s1

    def test_add_with_duplicate_index(self):
        # GH14227
        s1 = pd.Series([1, 2], index=[1, 1])
        s2 = pd.Series([10, 10], index=[1, 2])
        result = s1 + s2
        expected = pd.Series([11, 12, np.nan], index=[1, 1, 2])
        tm.assert_series_equal(result, expected)

    def test_add_na_handling(self):
        ser = pd.Series(
            [Decimal("1.3"), Decimal("2.3")], index=[date(2012, 1, 1), date(2012, 1, 2)]
        )

        result = ser + ser.shift(1)
        result2 = ser.shift(1) + ser
        assert pd.isna(result.iloc[0])
        assert pd.isna(result2.iloc[0])

    def test_add_corner_cases(self, datetime_series):
        empty = pd.Series([], index=pd.Index([]), dtype=np.float64)

        result = datetime_series + empty
        assert np.isnan(result).all()

        result = empty + empty
        assert len(result) == 0

    def test_add_float_plus_int(self, datetime_series):
        # float + int
        int_ts = datetime_series.astype(int)[:-5]
        added = datetime_series + int_ts
        expected = pd.Series(
            datetime_series.values[:-5] + int_ts.values,
            index=datetime_series.index[:-5],
            name="ts",
        )
        tm.assert_series_equal(added[:-5], expected)

    def test_mul_empty_int_corner_case(self):
        s1 = pd.Series([], [], dtype=np.int32)
        s2 = pd.Series({"x": 0.0})
        tm.assert_series_equal(s1 * s2, pd.Series([np.nan], index=["x"]))

    def test_sub_datetimelike_align(self):
        # GH#7500
        # datetimelike ops need to align
        dt = pd.Series(pd.date_range("2012-1-1", periods=3, freq="D", unit="ns"))
        dt.iloc[2] = np.nan
        dt2 = dt[::-1]

        expected = pd.Series([timedelta(0), timedelta(0), pd.NaT], dtype="m8[ns]")
        # name is reset
        result = dt2 - dt
        tm.assert_series_equal(result, expected)

        expected = pd.Series(expected, name=0)
        result = (dt2.to_frame() - dt.to_frame())[0]
        tm.assert_series_equal(result, expected)

    def test_alignment_doesnt_change_tz(self):
        # GH#33671
        dti = pd.date_range("2016-01-01", periods=10, tz="CET")
        dti_utc = dti.tz_convert("UTC")
        ser = pd.Series(10, index=dti)
        ser_utc = pd.Series(10, index=dti_utc)

        # we don't care about the result, just that original indexes are unchanged
        ser * ser_utc

        assert ser.index is dti
        assert ser_utc.index is dti_utc

    def test_alignment_categorical(self):
        # GH13365
        cat = pd.Categorical(["3z53", "3z53", "LoJG", "LoJG", "LoJG", "N503"])
        ser1 = pd.Series(2, index=cat)
        ser2 = pd.Series(2, index=cat[:-1])
        result = ser1 * ser2

        exp_index = ["3z53"] * 4 + ["LoJG"] * 9 + ["N503"]
        exp_index = pd.CategoricalIndex(exp_index, categories=cat.categories)
        exp_values = [4.0] * 13 + [np.nan]
        expected = pd.Series(exp_values, exp_index)

        tm.assert_series_equal(result, expected)

    def test_arithmetic_with_duplicate_index(self):
        # GH#8363
        # integer ops with a non-unique index
        index = [2, 2, 3, 3, 4]
        ser = pd.Series(np.arange(1, 6, dtype="int64"), index=index)
        other = pd.Series(np.arange(5, dtype="int64"), index=index)
        result = ser - other
        expected = pd.Series(1, index=[2, 2, 3, 3, 4])
        tm.assert_series_equal(result, expected)

        # GH#8363
        # datetime ops with a non-unique index
        ser = pd.Series(
            pd.date_range("20130101 09:00:00", periods=5, unit="ns"), index=index
        )
        other = pd.Series(pd.date_range("20130101", periods=5, unit="ns"), index=index)
        result = ser - other
        expected = pd.Series(
            pd.Timedelta("9 hours"), index=[2, 2, 3, 3, 4], dtype="m8[ns]"
        )
        tm.assert_series_equal(result, expected)

    def test_masked_and_non_masked_propagate_na(self):
        # GH#45810
        ser1 = pd.Series([0, np.nan], dtype="float")
        ser2 = pd.Series([0, 1], dtype="Int64")
        result = ser1 * ser2
        expected = pd.Series([0, pd.NA], dtype="Float64")
        tm.assert_series_equal(result, expected)

    def test_mask_div_propagate_na_for_non_na_dtype(self):
        # GH#42630
        ser1 = pd.Series([15, pd.NA, 5, 4], dtype="Int64")
        ser2 = pd.Series([15, 5, np.nan, 4])
        result = ser1 / ser2
        expected = pd.Series([1.0, pd.NA, pd.NA, 1.0], dtype="Float64")
        tm.assert_series_equal(result, expected)

        result = ser2 / ser1
        tm.assert_series_equal(result, expected)

    @pytest.mark.parametrize("val", [3, 3.5])
    def test_add_list_to_masked_array(self, val):
        # GH#22962, behavior changed by GH#62552
        ser = pd.Series([1, None, 3], dtype="Int64")
        result = ser + [1, None, val]  # noqa: RUF005
        expected = pd.Series([2, pd.NA, 3 + val], dtype="Float64")
        tm.assert_series_equal(result, expected)

        result = [1, None, val] + ser  # noqa: RUF005
        tm.assert_series_equal(result, expected)

    def test_add_list_to_masked_array_boolean(self):
        # GH#22962
        ser = pd.Series([True, None, False], dtype="boolean")
        result = ser + [True, None, True]  # noqa: RUF005
        expected = pd.Series([2, pd.NA, 1], dtype=object)
        tm.assert_series_equal(result, expected)

        result = [True, None, True] + ser  # noqa: RUF005
        tm.assert_series_equal(result, expected)

    def test_subtraction_index_name_type_mismatch_regression(self):
        # GH#57524
        s1 = pd.Series(
            [23, 22, 21],
            index=pd.Index(["a", "b", "c"], name="index a"),
            dtype="Int64",
        )
        s2 = pd.Series(
            [21, 22, 23],
            index=pd.Index(
                ["a", "b", "c"],
                name="index b",
                dtype="string",
            ),
            dtype="Int64",
        )

        result = s1 - s2
        expected = pd.Series([2, 0, -2], index=s1.index, dtype="Int64")

        tm.assert_series_equal(result, expected)


# ------------------------------------------------------------------
# Comparisons


class TestSeriesFlexComparison:
    @pytest.mark.parametrize("axis", [0, None, "index"])
    def test_comparison_flex_basic(self, axis, comparison_op):
        left = pd.Series(np.random.default_rng(2).standard_normal(10))
        right = pd.Series(np.random.default_rng(2).standard_normal(10))
        result = getattr(left, comparison_op.__name__)(right, axis=axis)
        expected = comparison_op(left, right)
        tm.assert_series_equal(result, expected)

    def test_comparison_bad_axis(self, comparison_op):
        left = pd.Series(np.random.default_rng(2).standard_normal(10))
        right = pd.Series(np.random.default_rng(2).standard_normal(10))

        msg = "No axis named 1 for object type"
        with pytest.raises(ValueError, match=msg):
            getattr(left, comparison_op.__name__)(right, axis=1)

    @pytest.mark.parametrize(
        "values, op",
        [
            ([False, False, True, False], "eq"),
            ([True, True, False, True], "ne"),
            ([False, False, True, False], "le"),
            ([False, False, False, False], "lt"),
            ([False, True, True, False], "ge"),
            ([False, True, False, False], "gt"),
        ],
    )
    def test_comparison_flex_alignment(self, values, op):
        left = pd.Series([1, 3, 2], index=list("abc"))
        right = pd.Series([2, 2, 2], index=list("bcd"))
        result = getattr(left, op)(right)
        expected = pd.Series(values, index=list("abcd"))
        tm.assert_series_equal(result, expected)

    @pytest.mark.parametrize(
        "left",
        [
            pd.Series(pd.Categorical(["a", "b", "a"])),
            pd.Series(pd.period_range("2020Q1", periods=3, freq="Q")),
        ],
        ids=["categorical", "period"],
    )
    def test_rhs_extension_array_eq_with_fill_value(self, left):
        # GH:#62467
        right = left._values  # this is an ExtensionArray

        result = left.eq(right, fill_value=left.iloc[0])
        expected = pd.Series([True, True, True])
        tm.assert_series_equal(result, expected)

    @pytest.mark.parametrize(
        "values, op, fill_value",
        [
            ([False, False, True, True], "eq", 2),
            ([True, True, False, False], "ne", 2),
            ([False, False, True, True], "le", 0),
            ([False, False, False, True], "lt", 0),
            ([True, True, True, False], "ge", 0),
            ([True, True, False, False], "gt", 0),
        ],
    )
    def test_comparison_flex_alignment_fill(self, values, op, fill_value):
        left = pd.Series([1, 3, 2], index=list("abc"))
        right = pd.Series([2, 2, 2], index=list("bcd"))
        result = getattr(left, op)(right, fill_value=fill_value)
        expected = pd.Series(values, index=list("abcd"))
        tm.assert_series_equal(result, expected)

    def test_eq_objects(self) -> None:
        # GH#62191 Test eq with Enum and List elements

        class Thing(Enum):
            FIRST = auto()
            SECOND = auto()

        left = pd.Series([Thing.FIRST, Thing.SECOND])
        py_l = [Thing.FIRST, Thing.SECOND]

        result = left.eq(Thing.FIRST)
        expected = pd.Series([True, False])
        tm.assert_series_equal(result, expected)

        result = left.eq(py_l)
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)

        result = left.eq(np.asarray(py_l))
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)

        result = left.eq(pd.Series(py_l))
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)

        result = pd.Series([[1, 2], [3, 4]]).eq([1, 2])
        expected = pd.Series([True, False])
        with pytest.raises(AssertionError):
            tm.assert_series_equal(result, expected)
        expected = pd.Series([False, False])
        tm.assert_series_equal(result, expected)

    def test_eq_with_index(self) -> None:
        # GH#62191 Test eq with non-trivial indices
        left = pd.Series([1, 2], index=[1, 0])
        py_l = [1, 2]

        # assuming Python list has the same index as the Series
        result = left.eq(py_l)
        expected = pd.Series([True, True], index=[1, 0])
        tm.assert_series_equal(result, expected)

        # assuming np.ndarray has the same index as the Series
        result = left.eq(np.asarray(py_l))
        expected = pd.Series([True, True], index=[1, 0])
        tm.assert_series_equal(result, expected)

        result = left.eq(pd.Series(py_l))
        expected = pd.Series([False, False])
        tm.assert_series_equal(result, expected)

        result = left.eq(pd.Series([2, 1]))
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)


class TestSeriesComparison:
    def test_comparison_different_length(self):
        a = pd.Series(["a", "b", "c"])
        b = pd.Series(["b", "a"])
        msg = "only compare identically-labeled Series"
        with pytest.raises(ValueError, match=msg):
            a < b

        a = pd.Series([1, 2])
        b = pd.Series([2, 3, 4])
        with pytest.raises(ValueError, match=msg):
            a == b

    @pytest.mark.parametrize("opname", ["eq", "ne", "gt", "lt", "ge", "le"])
    def test_ser_flex_cmp_return_dtypes(self, opname):
        # GH#15115
        ser = pd.Series([1, 3, 2], index=range(3))
        const = 2
        result = getattr(ser, opname)(const).dtypes
        expected = np.dtype("bool")
        assert result == expected

    @pytest.mark.parametrize("opname", ["eq", "ne", "gt", "lt", "ge", "le"])
    def test_ser_flex_cmp_return_dtypes_empty(self, opname):
        # GH#15115 empty Series case
        ser = pd.Series([1, 3, 2], index=range(3))
        empty = ser.iloc[:0]
        const = 2
        result = getattr(empty, opname)(const).dtypes
        expected = np.dtype("bool")
        assert result == expected

    @pytest.mark.parametrize(
        "names", [(None, None, None), ("foo", "bar", None), ("baz", "baz", "baz")]
    )
    def test_ser_cmp_result_names(self, names, comparison_op):
        # datetime64 dtype
        op = comparison_op
        dti = pd.date_range("1949-06-07 03:00:00", freq="h", periods=5, name=names[0])
        ser = pd.Series(dti).rename(names[1])
        result = op(ser, dti)
        assert result.name == names[2]

        # datetime64tz dtype
        dti = dti.tz_localize("US/Central")
        dti = pd.DatetimeIndex(dti, freq="infer")  # freq not preserved by tz_localize
        ser = pd.Series(dti).rename(names[1])
        result = op(ser, dti)
        assert result.name == names[2]

        # timedelta64 dtype
        tdi = dti - dti.shift(1)
        ser = pd.Series(tdi).rename(names[1])
        result = op(ser, tdi)
        assert result.name == names[2]

        # interval dtype
        if op in [operator.eq, operator.ne]:
            # interval dtype comparisons not yet implemented
            ii = pd.interval_range(start=0, periods=5, name=names[0])
            ser = pd.Series(ii).rename(names[1])
            result = op(ser, ii)
            assert result.name == names[2]

        # categorical
        if op in [operator.eq, operator.ne]:
            # categorical dtype comparisons raise for inequalities
            cidx = tdi.astype("category")
            ser = pd.Series(cidx).rename(names[1])
            result = op(ser, cidx)
            assert result.name == names[2]

    def test_comparisons(self):
        s = pd.Series(["a", "b", "c"])
        s2 = pd.Series([False, True, False])

        # it works!
        exp = pd.Series([False, False, False])
        tm.assert_series_equal(s == s2, exp)
        tm.assert_series_equal(s2 == s, exp)

    # -----------------------------------------------------------------
    # Categorical Dtype Comparisons

    def test_categorical_comparisons(self):
        # GH#8938
        # allow equality comparisons
        a = pd.Series(list("abc"), dtype="category")
        b = pd.Series(list("abc"), dtype="object")
        c = pd.Series(["a", "b", "cc"], dtype="object")
        d = pd.Series(list("acb"), dtype="object")
        e = pd.Categorical(list("abc"))
        f = pd.Categorical(list("acb"))

        # vs scalar
        assert not (a == "a").all()
        assert ((a != "a") == ~(a == "a")).all()

        assert not ("a" == a).all()
        assert (a == "a")[0]
        assert ("a" == a)[0]
        assert not ("a" != a)[0]

        # vs list-like
        assert (a == a).all()
        assert not (a != a).all()

        assert (a == list(a)).all()
        assert (a == b).all()
        assert (b == a).all()
        assert ((~(a == b)) == (a != b)).all()
        assert ((~(b == a)) == (b != a)).all()

        assert not (a == c).all()
        assert not (c == a).all()
        assert not (a == d).all()
        assert not (d == a).all()

        # vs a cat-like
        assert (a == e).all()
        assert (e == a).all()
        assert not (a == f).all()
        assert not (f == a).all()

        assert (~(a == e) == (a != e)).all()
        assert (~(e == a) == (e != a)).all()
        assert (~(a == f) == (a != f)).all()
        assert (~(f == a) == (f != a)).all()

        # non-equality is not comparable
        msg = "can only compare equality or not"
        with pytest.raises(TypeError, match=msg):
            a < b
        with pytest.raises(TypeError, match=msg):
            b < a
        with pytest.raises(TypeError, match=msg):
            a > b
        with pytest.raises(TypeError, match=msg):
            b > a

    def test_unequal_categorical_comparison_raises_type_error(self):
        # unequal comparison should raise for unordered cats
        cat = pd.Series(pd.Categorical(list("abc")))
        msg = "can only compare equality or not"
        with pytest.raises(TypeError, match=msg):
            cat > "b"

        cat = pd.Series(pd.Categorical(list("abc"), ordered=False))
        with pytest.raises(TypeError, match=msg):
            cat > "b"

        # https://github.com/pandas-dev/pandas/issues/9836#issuecomment-92123057
        # and following comparisons with scalars not in categories should raise
        # for unequal comps, but not for equal/not equal
        cat = pd.Series(pd.Categorical(list("abc"), ordered=True))

        msg = "Invalid comparison between dtype=category and str"
        with pytest.raises(TypeError, match=msg):
            cat < "d"
        with pytest.raises(TypeError, match=msg):
            cat > "d"
        with pytest.raises(TypeError, match=msg):
            "d" < cat
        with pytest.raises(TypeError, match=msg):
            "d" > cat

        tm.assert_series_equal(cat == "d", pd.Series([False, False, False]))
        tm.assert_series_equal(cat != "d", pd.Series([True, True, True]))

    # -----------------------------------------------------------------

    def test_comparison_tuples(self):
        # GH#11339
        # comparisons vs tuple
        s = pd.Series([(1, 1), (1, 2)])

        result = s == (1, 2)
        expected = pd.Series([False, True])
        tm.assert_series_equal(result, expected)

        result = s != (1, 2)
        expected = pd.Series([True, False])
        tm.assert_series_equal(result, expected)

        result = s == (0, 0)
        expected = pd.Series([False, False])
        tm.assert_series_equal(result, expected)

        result = s != (0, 0)
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)

        s = pd.Series([(1, 1), (1, 1)])

        result = s == (1, 1)
        expected = pd.Series([True, True])
        tm.assert_series_equal(result, expected)

        result = s != (1, 1)
        expected = pd.Series([False, False])
        tm.assert_series_equal(result, expected)

    def test_comparison_frozenset(self):
        ser = pd.Series([frozenset([1]), frozenset([1, 2])])

        result = ser == frozenset([1])
        expected = pd.Series([True, False])
        tm.assert_series_equal(result, expected)

    def test_comparison_operators_with_nas(self, comparison_op):
        ser = pd.Series(pd.bdate_range("1/1/2000", periods=10), dtype=object)
        ser[::2] = np.nan

        # test that comparisons work
        val = ser[5]

        result = comparison_op(ser, val)
        expected = comparison_op(ser.dropna(), val).reindex(ser.index)

        if comparison_op is operator.ne:
            expected = expected.fillna(True).astype(bool)
        else:
            expected = expected.fillna(False).astype(bool)

        tm.assert_series_equal(result, expected)

    def test_ne(self):
        ts = pd.Series([3, 4, 5, 6, 7], [3, 4, 5, 6, 7], dtype=float)
        expected = np.array([True, True, False, True, True])
        tm.assert_numpy_array_equal(ts.index != 5, expected)
        tm.assert_numpy_array_equal(~(ts.index == 5), expected)

    @pytest.mark.parametrize("right_data", [[2, 2, 2], [2, 2, 2, 2]])
    def test_comp_ops_df_compat(self, right_data, frame_or_series):
        # GH 1134
        # GH 50083 to clarify that index and columns must be identically labeled
        left = pd.Series([1, 2, 3], index=list("ABC"), name="x")
        right = pd.Series(right_data, index=list("ABDC")[: len(right_data)], name="x")
        if frame_or_series is not pd.Series:
            msg = (
                rf"Can only compare identically-labeled \(both index and columns\) "
                f"{frame_or_series.__name__} objects"
            )
            left = left.to_frame()
            right = right.to_frame()
        else:
            msg = (
                f"Can only compare identically-labeled {frame_or_series.__name__} "
                f"objects"
            )

        with pytest.raises(ValueError, match=msg):
            left == right
        with pytest.raises(ValueError, match=msg):
            right == left

        with pytest.raises(ValueError, match=msg):
            left != right
        with pytest.raises(ValueError, match=msg):
            right != left

        with pytest.raises(ValueError, match=msg):
            left < right
        with pytest.raises(ValueError, match=msg):
            right < left

    def test_compare_series_interval_keyword(self):
        # GH#25338
        ser = pd.Series(["IntervalA", "IntervalB", "IntervalC"])
        result = ser == "IntervalA"
        expected = pd.Series([True, False, False])
        tm.assert_series_equal(result, expected)


# ------------------------------------------------------------------
# Unsorted
#  These arithmetic tests were previously in other files, eventually
#  should be parametrized and put into tests.arithmetic


class TestTimeSeriesArithmetic:
    def test_series_add_tz_mismatch_converts_to_utc(self):
        rng = pd.date_range("1/1/2011", periods=100, freq="h", tz="utc")

        perm = np.random.default_rng(2).permutation(100)[:90]
        ser1 = pd.Series(
            np.random.default_rng(2).standard_normal(90),
            index=rng.take(perm).tz_convert("US/Eastern"),
        )

        perm = np.random.default_rng(2).permutation(100)[:90]
        ser2 = pd.Series(
            np.random.default_rng(2).standard_normal(90),
            index=rng.take(perm).tz_convert("Europe/Berlin"),
        )

        result = ser1 + ser2

        uts1 = ser1.tz_convert("utc")
        uts2 = ser2.tz_convert("utc")
        expected = uts1 + uts2

        # sort since input indexes are not equal
        expected = expected.sort_index()

        assert result.index.tz is UTC
        tm.assert_series_equal(result, expected)

    def test_series_add_aware_naive_raises(self):
        rng = pd.date_range("1/1/2011", periods=10, freq="h")
        ser = pd.Series(np.random.default_rng(2).standard_normal(len(rng)), index=rng)

        ser_utc = ser.tz_localize("utc")

        msg = "Cannot join tz-naive with tz-aware DatetimeIndex"
        with pytest.raises(Exception, match=msg):
            ser + ser_utc

        with pytest.raises(Exception, match=msg):
            ser_utc + ser

    # TODO: belongs in tests/arithmetic?
    def test_datetime_understood(self, unit):
        # Ensures it doesn't fail to create the right series
        # reported in issue#16726
        series = pd.Series(pd.date_range("2012-01-01", periods=3, unit=unit))
        offset = pd.offsets.DateOffset(days=6)
        result = series - offset
        exp_dti = pd.to_datetime(["2011-12-26", "2011-12-27", "2011-12-28"]).as_unit(
            unit
        )
        expected = pd.Series(exp_dti)
        tm.assert_series_equal(result, expected)

    def test_align_date_objects_with_datetimeindex(self):
        rng = pd.date_range("1/1/2000", periods=20)
        ts = pd.Series(np.random.default_rng(2).standard_normal(20), index=rng)

        ts_slice = ts[5:]
        ts2 = ts_slice.copy()
        ts2.index = [x.date() for x in ts2.index]

        # GH#62158 alignment joins date-object Index with DatetimeIndex
        msg = "Alignment of a DataFrame/Series with a DatetimeIndex"
        with tm.assert_produces_warning(Pandas4Warning, match=msg):
            result = ts + ts2
            result2 = ts2 + ts
        expected = ts + ts[5:]
        expected.index = expected.index._with_freq(None)
        tm.assert_series_equal(result, expected)
        tm.assert_series_equal(result2, expected)


class TestNamePreservation:
    @pytest.mark.parametrize(
        "box", [list, tuple, np.array, pd.Index, pd.Series, pd.array]
    )
    @pytest.mark.parametrize("flex", [True, False])
    def test_series_ops_name_retention(self, flex, box, names, all_binary_operators):
        # GH#33930 consistent name-retention
        op = all_binary_operators

        left = pd.Series(range(10), name=names[0])
        right = pd.Series(range(10), name=names[1])

        name = op.__name__.strip("_")
        is_logical = name in ["and", "rand", "xor", "rxor", "or", "ror"]

        msg = (
            r"Logical ops \(and, or, xor\) between Pandas objects and "
            "dtype-less sequences"
        )

        right = box(right)
        if flex:
            if is_logical:
                # Series doesn't have these as flex methods
                return

            warn = None
            tuple_msg = "with a tuple is deprecated"
            if box is tuple:
                warn = Pandas4Warning
            with tm.assert_produces_warning(warn, match=tuple_msg):
                result = getattr(left, name)(right)
        else:
            if is_logical and box in [list, tuple]:
                with pytest.raises(TypeError, match=msg):
                    # GH#52264 logical ops with dtype-less sequences deprecated
                    op(left, right)
                return

            warn = None
            depr_msg = "In a future version these will be treated as scalar-like"
            if box is tuple:
                # GH#62423 dunder ops with a tuple are deprecated
                warn = Pandas4Warning
            with tm.assert_produces_warning(warn, match=depr_msg):
                result = op(left, right)

        assert isinstance(result, pd.Series)
        if box in [pd.Index, pd.Series]:
            assert result.name is names[2] or result.name == names[2]
        else:
            assert result.name is names[0] or result.name == names[0]

    def test_binop_maybe_preserve_name(self, datetime_series):
        # names match, preserve
        result = datetime_series * datetime_series
        assert result.name == datetime_series.name
        result = datetime_series.mul(datetime_series)
        assert result.name == datetime_series.name

        result = datetime_series * datetime_series[:-2]
        assert result.name == datetime_series.name

        # names don't match, don't preserve
        cp = datetime_series.copy()
        cp.name = "something else"
        result = datetime_series + cp
        assert result.name is None
        result = datetime_series.add(cp)
        assert result.name is None

        ops = ["add", "sub", "mul", "div", "truediv", "floordiv", "mod", "pow"]
        ops = ops + ["r" + op for op in ops]
        for op in ops:
            # names match, preserve
            ser = datetime_series.copy()
            result = getattr(ser, op)(ser)
            assert result.name == datetime_series.name

            # names don't match, don't preserve
            cp = datetime_series.copy()
            cp.name = "changed"
            result = getattr(ser, op)(cp)
            assert result.name is None

    def test_scalarop_preserve_name(self, datetime_series):
        result = datetime_series * 2
        assert result.name == datetime_series.name


class TestInplaceOperations:
    @pytest.mark.parametrize(
        "dtype1, dtype2, dtype_expected, dtype_mul",
        (
            ("Int64", "Int64", "Int64", "Int64"),
            ("float", "float", "float", "float"),
            ("Int64", "float", "Float64", "Float64"),
            ("Int64", "Float64", "Float64", "Float64"),
        ),
    )
    def test_series_inplace_ops(self, dtype1, dtype2, dtype_expected, dtype_mul):
        # GH 37910

        ser1 = pd.Series([1], dtype=dtype1)
        ser2 = pd.Series([2], dtype=dtype2)
        ser1 += ser2
        expected = pd.Series([3], dtype=dtype_expected)
        tm.assert_series_equal(ser1, expected)

        ser1 -= ser2
        expected = pd.Series([1], dtype=dtype_expected)
        tm.assert_series_equal(ser1, expected)

        ser1 *= ser2
        expected = pd.Series([2], dtype=dtype_mul)
        tm.assert_series_equal(ser1, expected)


def test_none_comparison(request, series_with_simple_index):
    series = series_with_simple_index

    if len(series) < 1:
        request.applymarker(
            pytest.mark.xfail(reason="Test doesn't make sense on empty data")
        )

    # bug brought up by #1079
    # changed from TypeError in 0.17.0
    series.iloc[0] = np.nan

    # noinspection PyComparisonWithNone
    result = series == None  # noqa: E711
    assert not result.iat[0]
    assert not result.iat[1]

    # noinspection PyComparisonWithNone
    result = series != None  # noqa: E711
    assert result.iat[0]
    assert result.iat[1]

    result = None == series  # noqa: E711
    assert not result.iat[0]
    assert not result.iat[1]

    result = None != series  # noqa: E711
    assert result.iat[0]
    assert result.iat[1]

    if lib.is_np_dtype(series.dtype, "M") or isinstance(
        series.dtype, pd.DatetimeTZDtype
    ):
        # Following DatetimeIndex (and Timestamp) convention,
        # inequality comparisons with Series[datetime64] raise
        msg = "Invalid comparison"
        with pytest.raises(TypeError, match=msg):
            None > series
        with pytest.raises(TypeError, match=msg):
            series > None
    else:
        result = None > series
        assert not result.iat[0]
        assert not result.iat[1]

        result = series < None
        assert not result.iat[0]
        assert not result.iat[1]


def test_series_varied_multiindex_alignment():
    # GH 20414
    s1 = pd.Series(
        range(8),
        index=pd.MultiIndex.from_product(
            [list("ab"), list("xy"), [1, 2]], names=["ab", "xy", "num"]
        ),
    )
    s2 = pd.Series(
        [1000 * i for i in range(1, 5)],
        index=pd.MultiIndex.from_product([list("xy"), [1, 2]], names=["xy", "num"]),
    )
    result = s1.loc[pd.IndexSlice[["a"], :, :]] + s2
    expected = pd.Series(
        [1000, 2001, 3002, 4003],
        index=pd.MultiIndex.from_tuples(
            [("a", "x", 1), ("a", "x", 2), ("a", "y", 1), ("a", "y", 2)],
            names=["ab", "xy", "num"],
        ),
    )
    tm.assert_series_equal(result, expected)


def test_rmod_consistent_large_series():
    # GH 29602
    result = pd.Series([2] * 10001).rmod(-1)
    expected = pd.Series([1] * 10001)

    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize(
    "index",
    [
        pd.date_range("2016-01-01", periods=3),
        pd.date_range("2016-01-01", tz="US/Pacific", periods=3),
        pd.timedelta_range("1 Day", periods=3),
    ],
)
def test_comparison_mismatched_datetime_units(index):
    # GH#63459

    ser = pd.Series(1, index=index)
    ser2 = pd.Series(1, index=index.as_unit("ns"))

    result = ser == ser2
    expected = pd.Series([True, True, True], index=ser.index)
    tm.assert_series_equal(result, expected)

    result2 = ser2 < ser
    expected2 = pd.Series([False, False, False], index=ser2.index)
    tm.assert_series_equal(result2, expected2)


def test_multiindex_single_entry_arith_preserves_all_levels():
    # GH#25891 - MultiIndex level dropped when multiplying two Series with a
    # single entry. When both Series have exactly one entry and overlapping
    # MultiIndex levels, all non-common index levels must be preserved in the
    # result.
    index1 = pd.MultiIndex.from_product([[], []], names=["T", "N"])
    s1 = pd.Series(index=index1, dtype=float)
    s1["T.1A", "N.0"] = 0.5

    index2 = pd.MultiIndex.from_product([[], []], names=["N", "M"])
    s2 = pd.Series(index=index2, dtype=float)
    s2["N.0", "M.0"] = 0.5

    expected_index = pd.MultiIndex.from_tuples(
        [("T.1A", "N.0", "M.0")], names=["T", "N", "M"]
    )
    expected = pd.Series([0.25], index=expected_index)

    # multiplication
    result = s1 * s2
    tm.assert_series_equal(result, expected)

    # addition
    result_add = s1 + s2
    tm.assert_series_equal(result_add, pd.Series([1.0], index=expected_index))

    # subtraction
    result_sub = s1 - s2
    tm.assert_series_equal(result_sub, pd.Series([0.0], index=expected_index))

    # division
    result_div = s1 / s2
    tm.assert_series_equal(result_div, pd.Series([1.0], index=expected_index))


# ----------------------------------------------------------------------
# GH#62423 deprecate non-standard listlikes in arithmetic/comparison ops

depr_msg = "In a future version these will be treated as scalar-like"

# factories for non-standard listlikes holding [4, 5, 6]
non_standard_listlikes = [
    pytest.param(lambda: (4, 5, 6), id="tuple"),
    pytest.param(lambda: range(4, 7), id="range"),
    pytest.param(lambda: deque([4, 5, 6]), id="deque"),
]


@pytest.mark.parametrize("box", non_standard_listlikes)
@pytest.mark.parametrize("klass", [pd.Series, pd.Index])
def test_arith_cmp_non_standard_listlike_deprecated(klass, box):
    # GH#62423 numpy-dtype Series/Index dunder ops with a non-standard listlike
    #  (tuple/range/deque) are deprecated in favor of scalar-like treatment
    obj = klass([1, 2, 3])

    with tm.assert_produces_warning(Pandas4Warning, match=depr_msg):
        obj + box()
    with tm.assert_produces_warning(Pandas4Warning, match=depr_msg):
        obj == box()


def test_arith_ea_backed_range_deprecated():
    # GH#62423 range is converted to an ndarray before it reaches the EA, so
    #  the Series-level arith path is responsible for the warning
    ser = pd.Series([1, 2, 3], dtype="Int64")
    with tm.assert_produces_warning(Pandas4Warning, match=depr_msg):
        ser + range(4, 7)


@pytest.mark.parametrize("box", non_standard_listlikes)
def test_cmp_object_dtype_non_standard_listlike_not_deprecated(box):
    # GH#62423 object dtype already treats a non-standard listlike as scalar-like
    #  on comparison, so it must not warn
    for obj in [pd.Series([1, 2, 3], dtype=object), pd.Index([1, 2, 3], dtype=object)]:
        with tm.assert_produces_warning(None):
            obj == box()


def test_cmp_multiindex_tuple_not_deprecated():
    # GH#62423 MultiIndex already treats a tuple as a single (scalar) entry
    mi = pd.MultiIndex.from_tuples([("a", 1), ("b", 2), ("c", 3)])
    with tm.assert_produces_warning(None):
        mi == ("a", 1)


def test_cmp_categorical_positional_listlike_deprecated():
    # GH#62423 a non-standard non-hashable listlike (deque) reaches the
    #  positional comparison branch and is deprecated; a hashable tuple/range is
    #  already treated as scalar-like and must not warn
    cat = pd.Categorical([1, 2, 3])
    with tm.assert_produces_warning(Pandas4Warning, match=depr_msg):
        cat == deque([1, 2, 3])
    for other in [(1, 2, 3), range(3)]:
        with tm.assert_produces_warning(None):
            cat == other
